package ait.mediation;

public class BlkQueueImpl<T> implements BlkQueue<T> {
    public BlkQueueImpl(int maxSize) {
        // TODO
        throw new UnsupportedOperationException("Not implemented");
    }

    @Override
    public void push(T message) {
        // TODO
        throw new UnsupportedOperationException("Not implemented");
    }

    @Override
    public T pop() {
        // TODO
        throw new UnsupportedOperationException("Not implemented");
    }
}
