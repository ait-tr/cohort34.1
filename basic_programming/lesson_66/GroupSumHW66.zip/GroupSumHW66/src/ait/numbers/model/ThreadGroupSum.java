package ait.numbers.model;

public class ThreadGroupSum extends GroupSum{
    public ThreadGroupSum(int[][] numberGroups) {
        super(numberGroups);
    }

    @Override
    public int computeSum() {
        // TODO Homework: reduce sum numbers of numberGroups, use Threads
        return 0;
    }
}
