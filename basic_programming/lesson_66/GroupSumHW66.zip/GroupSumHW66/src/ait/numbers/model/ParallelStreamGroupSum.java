package ait.numbers.model;

public class ParallelStreamGroupSum extends GroupSum{
    public ParallelStreamGroupSum(int[][] numberGroups) {
        super(numberGroups);
    }

    @Override
    public int computeSum() {
        // TODO Advanced Homework: reduce sum numbers of numberGroups, use Arrays.stream(...).parallel()
        return 0;
    }
}
