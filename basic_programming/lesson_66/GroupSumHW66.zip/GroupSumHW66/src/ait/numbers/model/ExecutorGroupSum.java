package ait.numbers.model;

public class ExecutorGroupSum extends GroupSum{
    public ExecutorGroupSum(int[][] numberGroups) {
        super(numberGroups);
    }

    @Override
    public int computeSum() {
        // TODO Homework: reduce sum numbers of numberGroups, use ExecutorService
        return 0;
    }
}
